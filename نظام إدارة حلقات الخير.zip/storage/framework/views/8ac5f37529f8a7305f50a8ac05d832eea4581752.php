<!-- Footer opened -->
	<div class="main-footer ht-40">
		<div class="container-fluid pd-t-0-f ht-100p">
			<span> جميع الحقوق محفوظة لكلية علوم الحاسوب  2022 &copy;</span>
		</div>
	</div>
<!-- Footer closed -->
<?php /**PATH C:\Users\Microzool\Desktop\CS - Copy\resources\views/layouts/footer.blade.php ENDPATH**/ ?>