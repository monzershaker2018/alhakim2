<?php $__env->startSection('css'); ?>

<style>
    body {
    background-color: #19123B
}

.card {
    border: none;
    border-top: 5px solid rgb(176, 106, 252);
    background: #212042;
    color: #57557A
}

p {
    font-weight: 600;
    font-size: 15px
}

.fab {
    display: flex;
    justify-content: center;
    align-items: center;
    border: none;
    background: #2A284D;
    height: 40px;
    width: 90px
}

.fab:hover {
    cursor: pointer
}



.division {
    float: none;
    position: relative;
    margin: 30px auto 20px;
    text-align: center;
    width: 100%;
    box-sizing: border-box
}

.division .line {
    border-top: 1.5px solid #57557A;
    ;
    position: absolute;
    top: 13px;
    width: 85%
}



.division span {
    font-weight: 600;
    font-size: 14px
}

.myform {
    padding: 0 25px 0 33px
}

.form-control {
    border: 1px solid #57557A;
    border-radius: 3px;
    background: #212042;
    margin-bottom: 20px;
    letter-spacing: 1px
}

.form-control:focus {
    border: 1px solid #57557A;
    border-radius: 3px;
    box-shadow: none;
    background: #212042;
    color: #fff;
    letter-spacing: 1px
}

.bn {
    text-decoration: underline
}

.bn:hover {
    cursor: pointer
}

.form-check-input {
    margin-top: 8px !important
}

.btn-primary {
    background: linear-gradient(135deg, rgba(176, 106, 252, 1) 39%, rgba(116, 17, 255, 1) 101%);
    border: none;
    border-radius: 50px
}

.btn-primary:focus {
    box-shadow: none;
    border: none
}

small {
    color: #F2CEFF
}

.far.fa-user {
    font-size: 13px
}

@media(min-width: 767px) {
    .bn {
        text-align: right
    }
}

@media(max-width: 767px) {
    .form-check {
        text-align: center
    }

    .bn {
        text-align: center;
        align-items: center
    }
}

@media(max-width: 450px) {
    .fab {
        width: 100%;
        height: 100%
    }

    .division .line {
        width: 50%
    }
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
				<!-- breadcrumb -->
				<div class="breadcrumb-header justify-content-between">
					<div class="my-auto">
						<div class="d-flex">
							<h4 class="content-title mb-0 my-auto">الرئيسية</h4><span class="text-muted mt-1 tx-13 mr-2 mb-0">/ تسجيل الدخول</span>
						</div>
					</div>

				</div>
				<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
				<!-- row -->
				<div class="row">


                    <div class="container">

                        <div class="row d-flex justify-content-center mt-5">

                            <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                                <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                                <div class="card py-3 px-2">

                                    <div class="division">
                                        <div class="row">
                                            <div class="col-3">
                                                <div class="line l"></div>
                                            </div>
                                            <div class="col-6"><span>تسجيل الدخول </span></div>
                                            <div class="col-3">
                                                <div class="line r"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <form class="myform" method="POST" action="<?php echo e(route('login')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                             <input type="email" class="form-control" placeholder="البريد الإلكتروني" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                                             <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                             <span class="invalid-feedback" role="alert">
                                                 <strong><?php echo e($message); ?></strong>
                                             </span>
                                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        <div class="form-group"> <input type="password" class="form-control" placeholder="كلمة المرور  " <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group mt-3">
                                             <button type="submit" class="btn btn-block btn-primary btn-lg"><small><i class="far fa-user pr-2"></i> تسجيل الدخول </small></button>
                                             </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>




				</div>
				<!-- row closed -->
			</div>
			<!-- Container closed -->
		</div>
		<!-- main-content closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Microzool\Desktop\نظام الحاكم لادارة وكالة السفر\resources\views/auth/login.blade.php ENDPATH**/ ?>